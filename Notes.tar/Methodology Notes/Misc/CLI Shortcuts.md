ctrl-a
	jump beginning of line