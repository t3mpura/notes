--path-as-is. 
	Use this option to make curl send the path exactly as provided in the URL, without removing any dot segments.
	useful for path traversal