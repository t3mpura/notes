hard link
	`ln /path/to/file <link_name>
	points to INODE

symbolic link example
	`ln -sf /path/to/file_1 <link_name>
	points to FILE

Pric Esc potential
	See [[Nested Symbolic Links]]