See [[Cheat Sheet - File Transfers]]
