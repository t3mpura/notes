```
REMOVE \ ESCAPE CHARACTERS BEFORE CRACKING
```

```
3 MAIN TOOLS

crackstation -- NTLMs GO HERE FIRST

john

hashcat
```

```
# basic john format

john <file> --wordlist=/usr/share/wordlists/rockyou.txt --rules=best64


# basic hashcat usage

FIRST: IDENTIFY HASH
	hashcat hash.txt /usr/share/wordlists/rockyou.txt

SECOND: run
	hashcat -m <value> hash.txt /usr/share/wordlists/rockyou.txt
```
When hash and john fail, also try an online cracker:
	https://crackstation.net/

#### Show Previously Cracked Hashes

Hashcat
	`hashcat -m 1000 hash.file /usr/share/wordlists/rockyou.txt --show

John
	`john hash.txt --show`

#### Password protected files
<>2john can convert database passwords to hashes that can be cracked

https://github.com/willstruggle/john/blob/master/
	Master file for all <>2john 


keepass
	keepass2john
		make dure to remove `<word>:` from beginning of hash then use HASHCAT
			`hashcat -m 13400 Database.kdbx.hash /usr/share/wordlists/rockyou.txt -r /usr/share/hashcat/rules/best64.rule --force`
	ssh keys
	etc...
	Attempt to decrypt using both john AND hashcat
	example
		captured id_rsa
			password protected
		ssh2john key > key.hash
		`hashcat -m <#> key.hash rockyou.txt
			if this does not work...
		`john --wordlist=rockyou.txt key.hash

Another example
	`keystore2john appmanager.keystore > appmanager.keystore.hash
	`john --wordlist=/usr/share/wordlists/rockyou.txt appmanager.keystore.hash
		Remove "database" from beginning
		leave the :
	`john --show


zip2john
	same thing
	may result in many hashes (for each subdirectory inside the zip)


#### Identify Hashes

```
hash-identifier
	input hash

```

```NOTE: john/hashcat SHOULD autoidentify the hash but sometimes they do not
	take the FIRST $<value> and grep it through hashcat -h to find the -m value to use

example:
	hashcat -h | grep '$2'
		3200 | bcrypt $2*$, Blowfish
```

#### Cracking with Salts
```
# Download binary
wget https://www.techsolvency.com/pub/bin/mdxfind/mdxfind.static -O mdxfind
chmod +x mdxfind 


# Usage
try default value if salt unknown, otherwise input salt
	echo "YOUR_SALT_HERE" > salt.txt
	
any known passwords mdxfind can use as reference?
	echo "known_password" > pass.txt 

now try and determine hash (iterations set to 5)
	echo "a2b4e80cd640aaa6e417febe095dcbfc" | ./mdxfind -h 'MD5' -s salt.txt pass.txt -i 5
	the results of this will show us how many iterations we actually need

final crack
	echo "844ffc2c7150b93c4133a6ff2e1a2dba" | ./mdxfind -h 'MD5PASSSALT' -s salt.txt /usr/sharewordlists/rockyou.txt -i <iterations we need>

```





Username Anarchy generates potential usernames based on a target's name.

| Command                               | Description                                                                                   |
| ------------------------------------- | --------------------------------------------------------------------------------------------- |
| `username-anarchy Jane Smith`         | Generate possible usernames for "Jane Smith"                                                  |
| `username-anarchy -i names.txt`       | Use a file (`names.txt`) with names for input. Can handle space, CSV, or TAB delimited names. |
| `username-anarchy -a --country us`    | Automatically generate usernames using common names from the US dataset.                      |
| `username-anarchy -l`                 | List available username format plugins.                                                       |
| `username-anarchy -f format1,format2` | Use specific format plugins for username generation (comma-separated).                        |
| `username-anarchy -@ example.com`     | Append `@example.com` as a suffix to each username.                                           |
| `username-anarchy --case-insensitive` | Generate usernames in case-insensitive (lowercase) format.                                    |

