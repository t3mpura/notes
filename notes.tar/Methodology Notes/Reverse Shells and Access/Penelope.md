Alternative to nc listener

auto upgrades to TTY

`./penelope.py <listen_port>`