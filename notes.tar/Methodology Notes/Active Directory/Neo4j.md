my creds

neo4j:neo



Neo4j Default creds
	neo4j:neo4j

Start Neo4j service
	`sudo neo4j start`
	Started neo4j (pid:334819). It is available at http://localhost:7474

Login to Neo4j
	`http://localhost:7474`
	neo4j:neo4j
	Change password to whatever we like
		neo4j:neo


Start Bloodhound on KALI
	`bloodhound`
	login with neo4j creds