always check anonymous auth

Need extra perms to do anything?
	try default creds
		admin:admin
		Admin:Admin
	`<User>:<User>`
	Any cred combos you have already found, etc

-A active mode
binary for binary mode

cannot `get` directories

Wanna transfer all files?
	`mget *`

able to put files?
	`put <file>`
	if yest, great!

Any files that seem to be useless? Check their properties ie author fields
	`exiftool <file>
	do this for ALL files you find that seem out of place

