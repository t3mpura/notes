anonymous auth
`mysql -h <Hostname> -u root --skip-ssl

authenticated auth
`mysql -h <hostname> -u <user> -p <database_name> -P <port> --skip-ssl`


local windows authentication
`c:\path\to\bin> mysql.exe -u root -p`



Retrieve Version
	`select version();`

Inspect Current Session's user
	`select system_user();`
	will show user and our remote connection

Show Databases
	`show databases;`
```
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| sys                |
| test               |
+--------------------+
```

Show Tables
	`show tables from <database>`

Inspecting User's encrypted password (example)
	`SELECT user, authentication_string FROM mysql.user WHERE user = 'offsec';`
```
+--------+------------------------------------------------------------------------+
| user   | authentication_string                                                  |
+--------+------------------------------------------------------------------------+
| offsec | $A$005$?qvorPp8#lTKH1j54xuw4C5VsXe5IAa1cFUYdQMiBxQVEzZG9XWd/e6|
+--------+------------------------------------------------------------------------+
```
pass is stored as [_Caching-SHA-256_ algorithm](https://dev.mysql.com/doc/refman/8.0/en/caching-sha2-pluggable-authentication.html).
	we could potentially reverse/crack this

#### Editing Databases
Sometimes we are able to modify entries in a SQL database

```
# Setting password equal to 'admin' (this is a sha1 hash)
# WHERE is a refernce to show which row we are modifying

UPDATE <table> SET password='df5b909019c9b1659e86e0d6bf8da81d6fa3499e' WHERE <column_1>='<value>';
```
