For SQLi, refer to PayloadAllTheThings
https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/SQL%20Injection/PostgreSQL%20Injection.md

PostgreSQL Enumeration
```
DBMS version 	SELECT version()
Database Name 	SELECT CURRENT_DATABASE()
Database Schema 	SELECT CURRENT_SCHEMA()
List PostgreSQL Users 	SELECT usename FROM pg_user
List Password Hashes 	SELECT usename, passwd FROM pg_shadow
List DB Administrators 	SELECT usename FROM pg_user WHERE usesuper IS TRUE
Current User 	SELECT user;
Current User 	SELECT current_user;
Current User 	SELECT session_user;
Current User 	SELECT usename FROM pg_user;
Current User 	SELECT getpgusername();
```

PostgreSQL Methodology
```
List Schemas 	
	SELECT DISTINCT(schemaname) FROM pg_tables
List Databases 	
	SELECT datname FROM pg_database
List Tables 	
	SELECT table_name FROM information_schema.tables
List Tables 	
	SELECT table_name FROM information_schema.tables WHERE table_schema='<SCHEMA_NAME>'
List Tables 	
	SELECT tablename FROM pg_tables WHERE schemaname = '<SCHEMA_NAME>'
List Columns 	
	SELECT column_name FROM information_schema.columns WHERE table_name='data_table'
```


PSQL Meta Commands
```
Connect
	`psql -h <db-address> -d <db-name> -U <username> -W`
	-w forces psql to ask for the user password before connection
	-p to specify port
	default user:pass is postgres:postgres

List all databases
	\l

Switch databases
	\c <database_name>

List database tables
	\dt

Describe a table
	\d
	\d+ <tabel_name>
		more info about a table

List all schemas
	\dn

List all users and their roles
	\du
	`\du <username>
		specific users

List all functions
	\df

List all views
	\dv

Save query results to a file
	\o <file_name>

Run commands from a file
	\i <file_name>
	for example if you have a .txt file that does \l \dt \du you can do it all at once

Quit
	\q

```
