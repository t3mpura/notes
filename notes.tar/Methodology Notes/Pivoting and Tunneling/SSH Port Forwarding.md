We can use this to access internal ports on servers if we have SSH access

Local Port Forwarding
```
# example of connecting KALI port 8000 to VICTIM port 8080

ssh -L 8000:localhost:8080 <user>@<ip_address>
```