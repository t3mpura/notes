#### Shortcuts
```
TAB
	autocomplete

Ctrl+SPACE
	menu of options
```

```
powershell -ep bypass
```

#### Cmdlets
```
$env:<VAR>
	print var from env

Clear-Host
	clear screen

Get-Alias

Get-ChildItem

Where-Object

Select-Object

OutFile

Format-List
	* optional
```

#### Operators
[Comparison Operators](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_comparison_operators?view=powershell-7.5)
```
-like
-match
```