some programs will allow this as an option

this allows you to output the results directly to the terminal than a file


very useful if you are running into permission issues...

can also PIPE into other commands