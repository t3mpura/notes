`tree -a -C
	hidden files