Start docker service
	`sudo systemctl enable docker --now`

Set up docker environment
	`sudo docker build -t <name_of_build> </path/to/dir>`