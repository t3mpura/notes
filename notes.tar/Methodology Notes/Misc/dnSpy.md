https://github.com/dnSpy/dnSpy
.NET debugger and assembly editor
