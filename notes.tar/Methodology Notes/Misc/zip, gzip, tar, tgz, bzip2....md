Remember `tldr`

7z instead of unzip can be useful
	extract:
	`7z x <file.zip> -o<dir>`

tar
	to archive (works on directories too)
		`tar cf <file>.tar <file>`


gzip
	use to compress files
gunzip
	uncompress files


`gzip <file.tar>
	results in `<file.tar.gz>


Compression to help with file transfer
```
# tar and gz in one command

tar czf <file>.tar.gz <file(s)>...

# extract

tar xvf <file>.tar.gz

```