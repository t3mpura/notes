#### Custom Wordlists
cewl
	URL spidering tool to make a cracking wordlist from web content
	`cewl --depth 2 --write path/to/wordlist.txt url`
need more options?
tldr cewl