GREAT TOOL
https://meyerweb.com/eric/tools/dencoder/

Burp is great but sometimes it prioritizes the wrong characters to encode...