NOTE: if a subdomain/vhost is configured for localhost only, this will not reveal it. `/etc/apache2/sites-enabled` will reveal it though

How to check if there are sub-domains/vhosts? -- ffuf!

```
# ffuf example
ffuf -u http://<domain> -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt -H "Host: FUZZ.<domain>"
	
	ctrl-c (quit) and look are the most common word length. then--
	
ffuf -u http://<domain> -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt -H "Host: FUZZ.<domain>" -fw <word-length>
	
	this will return any subdomains if they exist
```


Wordlists to try (DO ALL)
```
-w /usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt

-w /usr/share/seclists/Discovery/DNS/bitquark-subdomains-top100000.txt

-w /usr/share/seclists/Discovery/Web-Content/directory-list-2.3-big.txt
```