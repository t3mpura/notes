2 scans for standard scans
	`feroxbuster --url <ip_address> --wordlist=/usr/share/seclists/Discovery/Web-Content/directory-list-2.3-big.txt
	or
	`feroxbuster --url <ip_address> --wordlist=/usr/share/dirb/wordlists/big.txt

Extension scan
	`-x php,txt,bak,html,zip,conf,py`

Scan manually identified sub directories
```
Use this when you manually identify a directory that was NOT identified by previous feroxbuster scans
```
	`feroxbuster --url <ip_address>/<dir> --wordlist=/usr/share/seclists/Discovery/Web-Content/directory-list-2.3-big.txt


Potentially specify files

How about scanning web extensions?
	`+x /usr/share/seclists/Discovery/Web-Content/web-extensions.txt